BELLEVILLE-DENTAL WEBSITE
=========================

Open index.html to start the website.

Pages:
- index.html
- about.html
- patient-education.html
- professional-education.html
- research.html
- products.html
- gallery.html
- contact.html
- queries.html
- sitemap.html

Assets:
- css/style.css
- js/script.js
- images/ (all website images and SVG icons)

Update in this version:
- Added a visible blue Dental Care tooth icon to the Dental Care service card.
- Kept the icon as an image file referenced directly from HTML.
- Fixed the trailing-space image path in products.html.
- Removed accidental browser/chat capture files from the images folder.

Note: Bootstrap 5 and Bootstrap Icons are loaded from their CDN links, so an internet connection is needed for those external libraries. The site's own HTML/CSS/JS/images are included in this ZIP.
