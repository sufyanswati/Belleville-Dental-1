document.addEventListener('DOMContentLoaded',()=>{
let v=localStorage.getItem("bellevilleVisitors");v=v?Number(v)+1:1;localStorage.setItem("bellevilleVisitors",v);const vc=document.getElementById("visitorCount");if(vc)vc.textContent=v;
let locationText="Detecting location...";
function tick(){const n=new Date(),t=document.getElementById("tickerContent");if(t)t.innerHTML="📅 Date: "+n.toLocaleDateString()+" &nbsp;&nbsp; 🕐 Time: "+n.toLocaleTimeString()+" &nbsp;&nbsp; 📍 Location: "+locationText}setInterval(tick,1000);tick();
if(navigator.geolocation)navigator.geolocation.getCurrentPosition(p=>{locationText="Lat: "+p.coords.latitude.toFixed(4)+", Long: "+p.coords.longitude.toFixed(4);tick()},()=>{locationText="Permission not available";tick()});
document.querySelectorAll(".filter-btn").forEach(b=>b.addEventListener("click",()=>{let f=b.dataset.filter;document.querySelectorAll(".product-item").forEach(p=>p.style.display=f==="all"||p.dataset.category===f?"block":"none")}));
document.querySelectorAll(".rating").forEach(r=>r.querySelectorAll("i").forEach(s=>s.addEventListener("click",()=>{let n=+s.dataset.value;r.querySelectorAll("i").forEach(x=>{let on=+x.dataset.value<=n;x.classList.toggle("selected",on);x.classList.toggle("bi-star-fill",on);x.classList.toggle("bi-star",!on)});r.nextElementSibling&&(r.nextElementSibling.textContent="Rated "+n+" out of 5")})));
const q=document.getElementById("queryForm");if(q)q.addEventListener("submit",e=>{e.preventDefault();alert("Thank you! Your query has been submitted.");q.reset()});
});

// Contact form demo handler
document.addEventListener("DOMContentLoaded", function () {
  const contactForm = document.getElementById("contactForm");
  const contactFormMessage = document.getElementById("contactFormMessage");

  if (contactForm && contactFormMessage) {
    contactForm.addEventListener("submit", function (event) {
      event.preventDefault();
      contactFormMessage.textContent = "Thank you! Your message has been received for this demo.";
      contactForm.reset();
    });
  }
});


/* Reliable Education and Patient Education dropdown toggle */
document.addEventListener("DOMContentLoaded", function () {
  const dropdowns = document.querySelectorAll(".dropdown");
  dropdowns.forEach(dropdown => {
    const toggle = dropdown.querySelector(".dropdown-toggle, [aria-haspopup='true'], > a");
    const menu = dropdown.querySelector(".dropdown-menu");
    if (!toggle || !menu) return;

    toggle.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();

      dropdowns.forEach(item => {
        if (item !== dropdown) {
          item.classList.remove("open");
          const otherMenu = item.querySelector(".dropdown-menu");
          if (otherMenu) otherMenu.classList.remove("show");
        }
      });

      dropdown.classList.toggle("open");
      menu.classList.toggle("show");
    });
  });

  document.addEventListener("click", function (event) {
    if (!event.target.closest(".dropdown")) {
      dropdowns.forEach(dropdown => {
        dropdown.classList.remove("open");
        const menu = dropdown.querySelector(".dropdown-menu");
        if (menu) menu.classList.remove("show");
      });
    }
  });
});
